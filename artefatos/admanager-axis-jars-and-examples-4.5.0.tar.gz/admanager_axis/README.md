Google Ad Manager API Java Client Library Examples
===========================================================

For instructions on how to get started, please visit github: https://github.com/googleads/googleads-java-lib

For API and client library updates and news, please follow our [Google+ Ads Developers page](https://plus.google.com/+GoogleAdsDevelopers/posts) and our [Google Ads Developers blog](http://googleadsdeveloper.blogspot.com/) 

For any issues relating to the API (not the library), please see the [Ad Manager API forum](https://groups.google.com/forum/#!forum/google-doubleclick-for-publishers-api)
